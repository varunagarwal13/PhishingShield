# 🛡️ Phishing Shield

Real-time phishing and malware link detector — Chrome Extension + Local AI Analysis Engine.

---

## Architecture

```
Browser click
    ↓
Chrome Extension (background.js)
    ↓ POST /analyse
FastAPI Server (127.0.0.1:8000)
    ├─ Redis Cache (< 5ms)
    ├─ Alexa Pre-check (30ms)
    ├─ WHOIS + Cert Age (300ms)
    └─ Parallel Analysis (2.5s max)
         ├─ URL ML Model (Person B)
         ├─ VirusTotal + GSB + PhishTank
         ├─ Puppeteer Screenshot + pHash
         ├─ NLP Urgency Model (Person B)
         └─ Image Scan (QR + Steg)
    ↓
Risk Score 0–100
    ├─ > 70 → BLOCK (block.html)
    ├─ 40–70 → WARN (banner)
    └─ < 40 → ALLOW
```

---

## Setup

### Prerequisites
- Python 3.11+
- Node.js 18+
- Docker Desktop

### Step 1: Clone and configure
```bash
git clone <your-repo>
cd phishing-classifier

cp server/.env.example server/.env
# Edit server/.env and add your API keys
```

### Step 2: Start Redis + PostgreSQL
```bash
docker-compose up -d
```

### Step 3: Install Python deps
```bash
cd server
python -m venv venv
source venv/bin/activate    # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### Step 4: Download Alexa allowlist
```bash
# Download and extract
curl -O https://s3.amazonaws.com/alexa-static/top-1m.csv.zip
unzip top-1m.csv.zip
# Take first 10000 lines, extract domain column
head -10000 top-1m.csv | cut -d',' -f2 > server/allowlist/alexa_top10k.txt
```

### Step 5: Start Puppeteer service
```bash
cd puppeteer
npm install
npm start
```

### Step 6: Start FastAPI server
```bash
cd server
python main.py
```

### Step 7: Load Chrome Extension
1. Open Chrome → `chrome://extensions`
2. Enable **Developer mode** (top right)
3. Click **Load unpacked**
4. Select the `extension/` folder

---

## API Keys (Free Tier)

| Service | URL | Rate Limit |
|---------|-----|-----------|
| VirusTotal | https://www.virustotal.com/gui/join-us | 4 req/min |
| Google Safe Browsing | https://console.cloud.google.com | 10,000/day |
| PhishTank | https://www.phishtank.com/developer_info.php | Unlimited |

---

## Adding Person B's Models

When Person B delivers model files, drop them in `server/models/`:

```
server/models/
├── url_model.pkl
├── nlp_model.pkl
├── brand_hashes.json
└── weights_config.json
```

Restart the server — it loads models at startup.

**Verify models loaded:**
```bash
curl http://127.0.0.1:8000/health
```

---

## Export Feedback for Person B

```bash
cd server
python -c "
import asyncio
from logger import export_feedback_csv, init_db
async def run():
    await init_db()
    await export_feedback_csv('feedback_export.csv')
asyncio.run(run())
"
```

---

## Setting PIN Override

In browser console (on any page):
```javascript
chrome.storage.local.set({ override_pin: '1234' })
```

---

## Project Structure

```
phishing-classifier/
├── extension/           # Chrome Extension
│   ├── manifest.json
│   ├── background.js    # Navigation interceptor
│   ├── content.js       # Warning banner
│   └── block.html       # Full block page
├── server/              # Python FastAPI
│   ├── main.py          # Entry point + pipeline
│   ├── cache.py         # Redis 3-layer cache
│   ├── precheck.py      # Alexa allowlist + URL features
│   ├── fast_check.py    # WHOIS + SSL cert age
│   ├── apis.py          # VT + GSB + PhishTank
│   ├── puppeteer_bridge.py  # Screenshot + pHash
│   ├── scoring.py       # Risk aggregation
│   ├── logger.py        # PostgreSQL logging
│   └── models/          # ← Person B drops files here
├── puppeteer/           # Node.js screenshot service
│   └── server.js
├── interfaces.md        # A↔B contract
└── docker-compose.yml
```
