"""
PHISHING SHIELD — fast_check.py
Fast definitive check: WHOIS domain age + SSL cert issuance age.
If domain registered today + cert issued today → early exit BLOCK (score ≥ 50).
Only ~30% of suspicious URLs make it past this stage.
"""

import asyncio
import logging
import ssl
import socket
from datetime import datetime, timezone, timedelta
from urllib.parse import urlparse

log = logging.getLogger("phishing_shield")


async def fast_definitive_check(url: str) -> dict:
    """
    Run WHOIS + SSL cert checks in parallel.
    Returns:
        { early_exit: True, verdict: {...} }  — if score ≥ 50 → immediate BLOCK
        { early_exit: False, partial_score: int, signals: list }  — continue to full analysis
    """
    domain = urlparse(url).netloc.lower().removeprefix("www.")

    # Run both checks concurrently
    whois_age, cert_age = await asyncio.gather(
        _get_domain_age_days(domain),
        _get_cert_age_hours(domain),
        return_exceptions=True
    )

    score = 0
    signals = []

    # ── WHOIS Domain Age ──
    if isinstance(whois_age, int):
        if whois_age == 0:
            score += 30
            signals.append("Domain registered today")
        elif whois_age <= 3:
            score += 30
            signals.append(f"Domain registered {whois_age} day(s) ago")
        elif whois_age <= 7:
            score += 20
            signals.append(f"Very new domain ({whois_age} days old)")
        elif whois_age <= 30:
            score += 10
            signals.append(f"New domain ({whois_age} days old)")
    elif isinstance(whois_age, Exception):
        # No WHOIS record = suspicious
        score += 15
        signals.append("No WHOIS record found")

    # ── SSL Certificate Age ──
    if isinstance(cert_age, int):
        if cert_age == 0:
            score += 20
            signals.append("SSL certificate issued in the last hour")
        elif cert_age <= 24:
            score += 20
            signals.append(f"SSL certificate issued {cert_age}h ago")
        elif cert_age <= 168:  # 7 days
            score += 10
            signals.append("SSL certificate less than 7 days old")

    # ── Early Exit? ──
    if score >= 50:
        verdict = {
            "action": "block",
            "score": score,
            "signals": signals[:3],
            "all_signals": signals,
        }
        return {"early_exit": True, "verdict": verdict}

    return {"early_exit": False, "partial_score": score, "signals": signals}


async def _get_domain_age_days(domain: str) -> int:
    """Returns domain age in days. Raises exception if WHOIS lookup fails."""
    loop = asyncio.get_event_loop()
    try:
        # Run blocking whois lookup in thread pool
        result = await asyncio.wait_for(
            loop.run_in_executor(None, _whois_lookup, domain),
            timeout=3.0
        )
        return result
    except asyncio.TimeoutError:
        raise Exception("WHOIS timeout")


def _whois_lookup(domain: str) -> int:
    """Synchronous WHOIS lookup (run in executor)."""
    import whois  # python-whois
    try:
        w = whois.whois(domain)
        creation_date = w.creation_date

        if isinstance(creation_date, list):
            creation_date = creation_date[0]

        if creation_date is None:
            raise Exception("No creation date in WHOIS")

        if creation_date.tzinfo is None:
            creation_date = creation_date.replace(tzinfo=timezone.utc)

        now = datetime.now(timezone.utc)
        age = (now - creation_date).days
        return max(0, age)
    except Exception as e:
        raise Exception(f"WHOIS failed: {e}")


async def _get_cert_age_hours(domain: str) -> int:
    """Returns SSL cert age in hours since issuance."""
    loop = asyncio.get_event_loop()
    try:
        result = await asyncio.wait_for(
            loop.run_in_executor(None, _ssl_cert_age, domain),
            timeout=3.0
        )
        return result
    except asyncio.TimeoutError:
        raise Exception("SSL timeout")


def _ssl_cert_age(domain: str) -> int:
    """Synchronous SSL certificate age check (run in executor)."""
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((domain, 443), timeout=3) as sock:
            with ctx.wrap_socket(sock, server_hostname=domain) as ssock:
                cert = ssock.getpeercert()

        not_before_str = cert.get("notBefore", "")
        if not not_before_str:
            raise Exception("No notBefore in cert")

        not_before = datetime.strptime(not_before_str, "%b %d %H:%M:%S %Y %Z")
        not_before = not_before.replace(tzinfo=timezone.utc)
        now = datetime.now(timezone.utc)
        age_hours = int((now - not_before).total_seconds() / 3600)
        return max(0, age_hours)
    except Exception as e:
        raise Exception(f"SSL check failed: {e}")
