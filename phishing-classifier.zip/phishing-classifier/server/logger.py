"""
PHISHING SHIELD — logger.py
Async PostgreSQL threat logging using asyncpg.
Logs every verdict + user actions + false positives.
Exports feedback CSV for Person B's retraining pipeline.
"""

import csv
import json
import logging
import os
from urllib.parse import urlparse

log = logging.getLogger("phishing_shield")

_pool = None
DB_URL = os.getenv("DATABASE_URL", "postgresql://admin:phishing123@localhost:5432/phishing_shield")


async def init_db():
    """Create connection pool and ensure table exists."""
    global _pool
    try:
        import asyncpg
        _pool = await asyncpg.create_pool(DB_URL, min_size=2, max_size=10)
        async with _pool.acquire() as conn:
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS threat_log (
                    id           SERIAL PRIMARY KEY,
                    url          TEXT NOT NULL,
                    domain       TEXT,
                    action       TEXT NOT NULL,
                    score        INTEGER,
                    signals      JSONB,
                    all_signals  JSONB,
                    user_action  TEXT,
                    user_flagged BOOLEAN DEFAULT FALSE,
                    created_at   TIMESTAMP WITH TIME ZONE DEFAULT NOW()
                );
                CREATE INDEX IF NOT EXISTS idx_threat_log_domain ON threat_log(domain);
                CREATE INDEX IF NOT EXISTS idx_threat_log_action ON threat_log(action);
                CREATE INDEX IF NOT EXISTS idx_threat_log_created ON threat_log(created_at);
            """)
        log.info("✓ PostgreSQL connected and table ready")
    except Exception as e:
        log.error(f"PostgreSQL init failed: {e}")
        _pool = None


async def log_verdict(url: str, verdict: dict, user_action: str = None):
    """Insert a threat verdict into the log table."""
    if _pool is None:
        return
    try:
        domain = urlparse(url).netloc
        async with _pool.acquire() as conn:
            await conn.execute("""
                INSERT INTO threat_log
                    (url, domain, action, score, signals, all_signals, user_action)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
            """,
                url, domain,
                verdict.get("action", "allow"),
                verdict.get("score", 0),
                json.dumps(verdict.get("signals", [])),
                json.dumps(verdict.get("all_signals", [])),
                user_action
            )
    except Exception as e:
        log.warning(f"Log write failed: {e}")


async def log_user_action(url: str, action: str):
    """Update the most recent log row for this URL with user's decision."""
    if _pool is None:
        return
    try:
        async with _pool.acquire() as conn:
            await conn.execute("""
                UPDATE threat_log
                SET user_action = $2
                WHERE id = (
                    SELECT id FROM threat_log
                    WHERE url = $1
                    ORDER BY created_at DESC
                    LIMIT 1
                )
            """, url, action)
    except Exception as e:
        log.warning(f"User action log failed: {e}")


async def log_false_positive(url: str):
    """Mark the most recent row for this URL as a false positive."""
    if _pool is None:
        return
    try:
        async with _pool.acquire() as conn:
            await conn.execute("""
                UPDATE threat_log
                SET user_flagged = TRUE
                WHERE id = (
                    SELECT id FROM threat_log
                    WHERE url = $1
                    ORDER BY created_at DESC
                    LIMIT 1
                )
            """, url)
        log.info(f"False positive logged: {url[:60]}")
    except Exception as e:
        log.warning(f"False positive log failed: {e}")


async def export_feedback_csv(filepath: str):
    """
    Export all rows where user bypassed a BLOCK verdict.
    This is Person B's retraining dataset.
    Schema: url, score, signals, user_action, created_at
    """
    if _pool is None:
        log.error("Database not connected — cannot export feedback")
        return

    try:
        async with _pool.acquire() as conn:
            rows = await conn.fetch("""
                SELECT url, domain, action, score,
                       all_signals, user_action, user_flagged, created_at
                FROM threat_log
                WHERE action IN ('block', 'warn')
                  AND (user_action = 'proceeded' OR user_flagged = TRUE)
                ORDER BY created_at DESC
            """)

        with open(filepath, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["url", "domain", "action", "score",
                             "all_signals", "user_action", "user_flagged", "created_at"])
            for row in rows:
                writer.writerow([
                    row["url"], row["domain"], row["action"], row["score"],
                    row["all_signals"], row["user_action"],
                    row["user_flagged"], row["created_at"]
                ])
        log.info(f"Feedback exported: {len(rows)} rows → {filepath}")
    except Exception as e:
        log.error(f"Feedback export failed: {e}")


async def get_stats() -> dict:
    """Basic stats for the admin dashboard."""
    if _pool is None:
        return {}
    try:
        async with _pool.acquire() as conn:
            stats = await conn.fetchrow("""
                SELECT
                    COUNT(*) AS total,
                    COUNT(*) FILTER (WHERE action='block') AS blocked,
                    COUNT(*) FILTER (WHERE action='warn')  AS warned,
                    COUNT(*) FILTER (WHERE action='allow') AS allowed,
                    COUNT(*) FILTER (WHERE user_flagged=TRUE) AS false_positives,
                    COUNT(*) FILTER (WHERE user_action='proceeded') AS bypassed
                FROM threat_log
            """)
            return dict(stats)
    except Exception as e:
        log.warning(f"Stats query failed: {e}")
        return {}
