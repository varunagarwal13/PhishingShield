"""
PHISHING SHIELD — scoring.py
Aggregates partial scores from all modules into a final 0–100 risk score.
Weights come from Person B's weights_config.json.
"""

import logging

log = logging.getLogger("phishing_shield")


def compute_score(
    module_results: list,
    weights: dict,
    fast_result: dict
) -> dict:
    """
    module_results = [url_res, api_res, visual_res, nlp_res, img_res]
    Each may be a dict, an Exception, or {} (stub/skipped).

    Returns: { action, score, signals (top 3), all_signals }
    """
    score = fast_result.get("partial_score", 0)
    signals: list[str] = list(fast_result.get("signals", []))

    # Unpack — order matches asyncio.gather() in main.py
    url_res   = _safe(module_results, 0)
    api_res   = _safe(module_results, 1)
    visual_res = _safe(module_results, 2)
    nlp_res   = _safe(module_results, 3)
    img_res   = _safe(module_results, 4)

    # ── Reputation APIs ──
    if api_res:
        if api_res.get("definitive"):
            # VirusTotal gave 5+ flags — definitive block
            return _make_verdict(api_res.get("score_override", 95),
                                  ["VirusTotal: flagged by 5+ antivirus engines"],
                                  ["VirusTotal: flagged by 5+ antivirus engines"])

        vt_flags = api_res.get("virustotal_flags", 0)
        if vt_flags > 0:
            added = min(vt_flags * weights.get("virustotal_per_flag", 10),
                        weights.get("virustotal_max", 50))
            score += added
            signals.append(f"VirusTotal: {vt_flags} engine(s) flagged this URL")

        if api_res.get("gsb_match"):
            score += weights.get("gsb_hit", 40)
            threat = api_res.get("gsb_threat_type", "phishing")
            signals.append(f"Google Safe Browsing: listed as {threat.lower()}")

        if api_res.get("phishtank_hit"):
            score += weights.get("phishtank_hit", 35)
            signals.append("PhishTank: confirmed phishing URL")

    # ── Visual Clone (pHash) ──
    if visual_res:
        if visual_res.get("visual_clone"):
            score += weights.get("visual_clone", 40)
            brand = visual_res.get("matched_brand", "unknown brand")
            signals.append(f"Page visually impersonates {brand.upper()}")

        dom = visual_res.get("dom_signals", {})
        if dom.get("hasPasswordField") and api_res.get("virustotal_flags", 0) == 0:
            score += weights.get("password_field_unknown", 10)
            signals.append("Login/password form on unverified domain")

        if dom.get("formActionMismatch"):
            score += weights.get("form_action_mismatch", 10)
            signals.append("Form submits to a different domain (credential theft pattern)")

        if dom.get("iframeAbuse"):
            score += weights.get("iframe_abuse", 15)
            signals.append("Cross-origin iframes detected (content injection)")

        if dom.get("rightClickDisabled"):
            score += 5
            signals.append("Right-click disabled (anti-inspection technique)")

    # ── URL Model (Person B's ML) ──
    if url_res:
        prob = url_res.get("phishing_probability", 0.0)
        if prob > 0.5:
            added = int(prob * weights.get("url_model_scale", 30))
            score += added
        signals.extend(url_res.get("signals", []))

    # ── NLP Urgency ──
    if nlp_res:
        urgency = nlp_res.get("urgency_score", 0.0)
        if urgency > 0.7:
            score += weights.get("nlp_urgency", 20)
            signals.append("High-urgency manipulation language detected")
        elif urgency > 0.5:
            score += 8
            signals.append("Suspicious urgency language in page content")

        patterns = nlp_res.get("detected_patterns", [])
        if patterns:
            signals.append(f"Phishing keywords found: {', '.join(patterns[:2])}")

    # ── Image Scan (future: QR + steganography) ──
    if img_res:
        if img_res.get("qr_url_flagged"):
            score += 25
            signals.append("Malicious URL found in embedded QR code")
        if img_res.get("steganography_detected"):
            score += 20
            signals.append("Hidden data detected in page images (steganography)")

    # ── Cap and deduplicate ──
    score = min(int(score), 100)
    all_signals = _deduplicate(signals)

    return _make_verdict(score, all_signals[:3], all_signals)


def _make_verdict(score: int, display_signals: list, all_signals: list) -> dict:
    if score > 70:
        action = "block"
    elif score >= 40:
        action = "warn"
    else:
        action = "allow"

    return {
        "action": action,
        "score": score,
        "signals": display_signals,
        "all_signals": all_signals,
    }


def _safe(lst: list, idx: int) -> dict:
    """Safely get item from list. Returns {} for Exception or missing."""
    try:
        val = lst[idx]
        if isinstance(val, Exception):
            return {}
        return val or {}
    except IndexError:
        return {}


def _deduplicate(items: list) -> list:
    seen = set()
    result = []
    for item in items:
        key = item.lower()
        if key not in seen:
            seen.add(key)
            result.append(item)
    return result
