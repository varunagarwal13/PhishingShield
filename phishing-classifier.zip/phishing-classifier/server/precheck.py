"""
PHISHING SHIELD — precheck.py
Fast pre-check: Alexa Top 10K allowlist + known-good domains.
Also provides URL feature extraction for Person B's ML model.
"""

import math
import os
import re
import string
from urllib.parse import urlparse
import logging

log = logging.getLogger("phishing_shield")

# ─────────────────────────────────────────────
# ALLOWLIST (loaded once at module import)
# ─────────────────────────────────────────────
KNOWN_GOOD = {
    "google.com", "youtube.com", "github.com", "stackoverflow.com",
    "wikipedia.org", "mozilla.org", "microsoft.com", "apple.com",
    "amazon.com", "linkedin.com", "twitter.com", "x.com",
    "facebook.com", "instagram.com", "reddit.com", "netflix.com",
    "openai.com", "anthropic.com", "cloudflare.com", "npmjs.com",
    # India
    "flipkart.com", "naukri.com", "irctc.co.in", "incometax.gov.in",
    "mygov.in", "digitalindia.gov.in", "uidai.gov.in",
}

_ALEXA_SET: set[str] = set()


def _load_alexa():
    global _ALEXA_SET
    path = os.path.join(os.path.dirname(__file__), "allowlist", "alexa_top10k.txt")
    if not os.path.exists(path):
        log.warning("alexa_top10k.txt not found — download it and place in server/allowlist/")
        return
    with open(path) as f:
        for line in f:
            domain = line.strip().lower()
            if domain:
                _ALEXA_SET.add(domain)
    log.info(f"✓ Alexa allowlist loaded: {len(_ALEXA_SET)} domains")


_load_alexa()


def _base_domain(url: str) -> str:
    """Extract base domain, stripping www. prefix."""
    try:
        netloc = urlparse(url).netloc.lower()
        return netloc.removeprefix("www.")
    except Exception:
        return ""


def is_obviously_safe(url: str) -> bool:
    """Returns True if URL is in Alexa Top 10K or known-good list. ~O(1)."""
    base = _base_domain(url)
    if not base:
        return False
    return base in _ALEXA_SET or base in KNOWN_GOOD


# ─────────────────────────────────────────────
# URL FEATURE EXTRACTION (for Person B's model)
# ─────────────────────────────────────────────
def shannon_entropy(s: str) -> float:
    """Compute Shannon entropy of a string."""
    if not s:
        return 0.0
    freq = {}
    for c in s:
        freq[c] = freq.get(c, 0) + 1
    total = len(s)
    return -sum((v / total) * math.log2(v / total) for v in freq.values())


def extract_url_features(url: str) -> dict:
    """
    Extract numerical features from a URL for the ML classifier.
    Keys must match what Person B's model was trained on.
    """
    try:
        parsed = urlparse(url)
        domain = parsed.netloc.lower().removeprefix("www.")
        path = parsed.path or ""
        full = url

        # Suspicious TLD list (high-risk)
        suspicious_tlds = {
            ".tk", ".ml", ".ga", ".cf", ".gq", ".xyz", ".top", ".club",
            ".online", ".site", ".website", ".space", ".live", ".click",
            ".download", ".zip", ".loan", ".men", ".work", ".party"
        }
        tld = "." + domain.split(".")[-1] if "." in domain else ""
        tld_risk = 1.0 if tld in suspicious_tlds else 0.0

        # Homoglyph / unicode check
        has_unicode = any(ord(c) > 127 for c in domain)

        # Levenshtein distance to top brands (simplified check)
        top_brands = ["paypal", "google", "amazon", "facebook", "netflix",
                      "apple", "microsoft", "sbi", "hdfc", "icici", "paytm"]
        min_brand_distance = min(
            _levenshtein(domain.split(".")[0], brand) for brand in top_brands
        )

        return {
            "url_length": len(full),
            "domain_length": len(domain),
            "num_dots": domain.count("."),
            "num_hyphens": domain.count("-"),
            "num_at_symbols": full.count("@"),
            "has_at_symbol": int("@" in full),
            "num_digits_in_domain": sum(c.isdigit() for c in domain),
            "entropy": shannon_entropy(domain),
            "path_length": len(path),
            "num_path_slashes": path.count("/"),
            "has_ip_address": int(bool(re.match(r"\d+\.\d+\.\d+\.\d+", domain))),
            "is_https": int(url.startswith("https")),
            "has_suspicious_keywords": int(
                any(kw in full.lower() for kw in [
                    "login", "verify", "secure", "account", "update",
                    "confirm", "banking", "password", "credential"
                ])
            ),
            "tld_risk_score": tld_risk,
            "has_unicode": int(has_unicode),
            "min_brand_distance": min_brand_distance,
            "has_double_slash_in_path": int("//" in path),
            "query_string_length": len(parsed.query),
            "num_subdomains": max(0, domain.count(".") - 1),
        }
    except Exception as e:
        log.error(f"Feature extraction error: {e}")
        return {}


def _levenshtein(s1: str, s2: str) -> int:
    """Simple Levenshtein distance."""
    if len(s1) < len(s2):
        return _levenshtein(s2, s1)
    if not s2:
        return len(s1)
    prev = list(range(len(s2) + 1))
    for i, c1 in enumerate(s1):
        curr = [i + 1]
        for j, c2 in enumerate(s2):
            curr.append(min(prev[j + 1] + 1, curr[j] + 1, prev[j] + (c1 != c2)))
        prev = curr
    return prev[-1]
