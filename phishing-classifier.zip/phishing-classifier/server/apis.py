"""
PHISHING SHIELD — apis.py
Reputation APIs: VirusTotal + Google Safe Browsing + PhishTank
All 3 called simultaneously. VT with 5+ flags → early exit BLOCK.
"""

import asyncio
import base64
import hashlib
import logging
import os

import aiohttp

log = logging.getLogger("phishing_shield")

VT_KEY   = os.getenv("VIRUSTOTAL_API_KEY", "")
GSB_KEY  = os.getenv("GOOGLE_SAFE_BROWSING_KEY", "")


async def call_reputation_apis(url: str, stop_event: asyncio.Event) -> dict:
    """
    Call all 3 reputation APIs concurrently.
    If VirusTotal returns 5+ engine flags → set stop_event and return definitive BLOCK signal.
    """
    if stop_event.is_set():
        return {}

    timeout = aiohttp.ClientTimeout(total=4)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        vt_task, gsb_task, pt_task = await asyncio.gather(
            _check_virustotal(url, session),
            _check_gsb(url, session),
            _check_phishtank(url, session),
            return_exceptions=True
        )

    result = {}

    # ── VirusTotal ──
    vt_flags = 0
    if isinstance(vt_task, dict):
        vt_flags = vt_task.get("positives", 0)
        result["virustotal_flags"] = vt_flags
        result["virustotal_total_engines"] = vt_task.get("total", 0)

        if vt_flags >= 5:
            stop_event.set()  # Broadcast STOP — this is definitive
            log.info(f"⚡ VirusTotal early exit: {vt_flags} flags")
            result["definitive"] = True
            result["score_override"] = 95
            return result
    else:
        result["virustotal_flags"] = 0

    # ── Google Safe Browsing ──
    if isinstance(gsb_task, dict):
        result["gsb_match"] = gsb_task.get("match", False)
        result["gsb_threat_type"] = gsb_task.get("threat_type", None)
    else:
        result["gsb_match"] = False

    # ── PhishTank ──
    if isinstance(pt_task, dict):
        result["phishtank_hit"] = pt_task.get("in_database", False)
        result["phishtank_verified"] = pt_task.get("verified", False)
    else:
        result["phishtank_hit"] = False

    return result


# ─────────────────────────────────────────────
# VIRUSTOTAL v3
# ─────────────────────────────────────────────
async def _check_virustotal(url: str, session: aiohttp.ClientSession) -> dict:
    if not VT_KEY:
        return {}

    # VT v3 uses URL-safe base64 of the URL as the ID
    url_id = base64.urlsafe_b64encode(url.encode()).decode().strip("=")
    headers = {"x-apikey": VT_KEY}

    try:
        async with session.get(
            f"https://www.virustotal.com/api/v3/urls/{url_id}",
            headers=headers
        ) as resp:
            if resp.status == 404:
                # URL not in VT database — submit it for analysis
                await _submit_vt_url(url, session, headers)
                return {"positives": 0, "total": 0}
            if resp.status != 200:
                return {}
            data = await resp.json()
            stats = data.get("data", {}).get("attributes", {}).get("last_analysis_stats", {})
            return {
                "positives": stats.get("malicious", 0) + stats.get("suspicious", 0),
                "total": sum(stats.values()),
            }
    except Exception as e:
        log.warning(f"VT error: {e}")
        return {}


async def _submit_vt_url(url: str, session: aiohttp.ClientSession, headers: dict):
    """Submit URL to VT for scanning (fire-and-forget)."""
    try:
        async with session.post(
            "https://www.virustotal.com/api/v3/urls",
            headers=headers,
            data={"url": url}
        ) as _:
            pass
    except Exception:
        pass


# ─────────────────────────────────────────────
# GOOGLE SAFE BROWSING v4
# ─────────────────────────────────────────────
async def _check_gsb(url: str, session: aiohttp.ClientSession) -> dict:
    if not GSB_KEY:
        return {}

    payload = {
        "client": {"clientId": "phishing-shield", "clientVersion": "1.0"},
        "threatInfo": {
            "threatTypes": [
                "MALWARE", "SOCIAL_ENGINEERING",
                "UNWANTED_SOFTWARE", "POTENTIALLY_HARMFUL_APPLICATION"
            ],
            "platformTypes": ["ANY_PLATFORM"],
            "threatEntryTypes": ["URL"],
            "threatEntries": [{"url": url}],
        },
    }

    try:
        async with session.post(
            f"https://safebrowsing.googleapis.com/v4/threatMatches:find?key={GSB_KEY}",
            json=payload
        ) as resp:
            if resp.status != 200:
                return {}
            data = await resp.json()
            matches = data.get("matches", [])
            if matches:
                return {
                    "match": True,
                    "threat_type": matches[0].get("threatType", "UNKNOWN")
                }
            return {"match": False}
    except Exception as e:
        log.warning(f"GSB error: {e}")
        return {}


# ─────────────────────────────────────────────
# PHISHTANK
# ─────────────────────────────────────────────
async def _check_phishtank(url: str, session: aiohttp.ClientSession) -> dict:
    """
    PhishTank lookup using their checkurl API.
    No API key required for basic usage.
    """
    try:
        url_hash = hashlib.md5(url.encode()).hexdigest()
        data = aiohttp.FormData()
        data.add_field("url", url)
        data.add_field("format", "json")
        data.add_field("app_key", os.getenv("PHISHTANK_API_KEY", ""))

        async with session.post(
            "https://checkurl.phishtank.com/checkurl/",
            data=data,
            headers={"User-Agent": "phishing-shield/1.0"}
        ) as resp:
            if resp.status != 200:
                return {}
            data = await resp.json(content_type=None)
            results = data.get("results", {})
            return {
                "in_database": results.get("in_database", False),
                "verified": results.get("verified", False),
                "valid": results.get("valid", False),
            }
    except Exception as e:
        log.warning(f"PhishTank error: {e}")
        return {}
