"""
PHISHING SHIELD — cache.py
Redis 3-layer cache: exact URL → domain-safe → domain-blocked
"""

import json
import logging
from urllib.parse import urlparse

log = logging.getLogger("phishing_shield")

# Lazy import: Redis connection created on first use
_redis = None

async def _get_redis():
    global _redis
    if _redis is None:
        try:
            import redis.asyncio as aioredis
            _redis = aioredis.from_url("redis://localhost:6379", decode_responses=True)
            await _redis.ping()
        except Exception as e:
            log.error(f"Redis connection failed: {e}")
            _redis = None
    return _redis


def _domain(url: str) -> str:
    try:
        return urlparse(url).netloc.lower()
    except Exception:
        return ""


async def check_cache(url: str) -> dict | None:
    """
    Check 3 cache layers in order:
    1. Exact URL match
    2. Domain-level safe cache
    3. Domain-level blocked cache
    Returns parsed verdict dict or None on miss.
    """
    r = await _get_redis()
    if r is None:
        return None  # Redis down → cache miss, proceed with analysis

    domain = _domain(url)
    keys = [f"url:{url}", f"domain_safe:{domain}", f"domain_blocked:{domain}"]

    try:
        pipe = r.pipeline()
        for k in keys:
            pipe.get(k)
        results = await pipe.execute()

        for val in results:
            if val:
                return json.loads(val)
    except Exception as e:
        log.warning(f"Cache read error: {e}")

    return None


async def write_cache(url: str, verdict: dict, ttl: int):
    """
    Write verdict to cache:
    - Always write exact URL key
    - Write domain_safe if action == allow
    - Write domain_blocked if action == block
    """
    r = await _get_redis()
    if r is None:
        return

    domain = _domain(url)
    action = verdict.get("action", "allow")
    data = json.dumps(verdict)

    try:
        pipe = r.pipeline()
        pipe.setex(f"url:{url}", ttl, data)

        if action == "allow":
            pipe.setex(f"domain_safe:{domain}", 21600, data)   # 6h
        elif action == "block":
            pipe.setex(f"domain_blocked:{domain}", 86400, data) # 24h
        # warn: only URL-level cache (domain may have safe pages too)

        await pipe.execute()
    except Exception as e:
        log.warning(f"Cache write error: {e}")


async def clear_url_cache(url: str):
    """
    Clear all cache entries for a URL + its domain.
    Called when user enters PIN override (false positive recovery).
    """
    r = await _get_redis()
    if r is None:
        return

    domain = _domain(url)
    keys = [f"url:{url}", f"domain_blocked:{domain}", f"domain_safe:{domain}"]

    try:
        await r.delete(*keys)
        log.info(f"Cache cleared for: {domain}")
    except Exception as e:
        log.warning(f"Cache clear error: {e}")
