"""
PHISHING SHIELD — main.py
FastAPI server at 127.0.0.1:8000
Full analysis pipeline: cache → precheck → fast_check → 5 parallel modules → scoring → verdict
"""

import asyncio
import json
import os
import logging
from contextlib import asynccontextmanager
from urllib.parse import urlparse

import joblib
import uvicorn
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from cache import check_cache, write_cache, clear_url_cache
from precheck import is_obviously_safe
from fast_check import fast_definitive_check
from apis import call_reputation_apis
from puppeteer_bridge import get_page_data
from scoring import compute_score
from logger import init_db, log_verdict, log_user_action, log_false_positive

load_dotenv()
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("phishing_shield")

# ─────────────────────────────────────────────
# STARTUP: Load models once
# ─────────────────────────────────────────────
MODELS = {}

def load_models():
    """Load Person B's models at startup. Use stubs if files not yet available."""
    base = os.path.join(os.path.dirname(__file__), "models")

    # URL classifier
    try:
        MODELS["url_model"] = joblib.load(os.path.join(base, "url_model.pkl"))
        log.info("✓ url_model.pkl loaded")
    except FileNotFoundError:
        MODELS["url_model"] = None
        log.warning("⚠ url_model.pkl not found — using stub (returns 0.0)")

    # NLP urgency classifier
    try:
        MODELS["nlp_model"] = joblib.load(os.path.join(base, "nlp_model.pkl"))
        log.info("✓ nlp_model.pkl loaded")
    except FileNotFoundError:
        MODELS["nlp_model"] = None
        log.warning("⚠ nlp_model.pkl not found — using stub (returns 0.0)")

    # Brand pHash library
    try:
        with open(os.path.join(base, "brand_hashes.json")) as f:
            raw = json.load(f)
        import imagehash
        MODELS["brand_hashes"] = {k: imagehash.hex_to_hash(v) for k, v in raw.items()}
        log.info(f"✓ brand_hashes.json loaded — {len(MODELS['brand_hashes'])} brands")
    except FileNotFoundError:
        MODELS["brand_hashes"] = {}
        log.warning("⚠ brand_hashes.json not found — visual clone check disabled")

    # Scoring weights
    try:
        with open(os.path.join(base, "weights_config.json")) as f:
            MODELS["weights"] = json.load(f)
        log.info("✓ weights_config.json loaded")
    except FileNotFoundError:
        # Default weights until Person B calibrates
        MODELS["weights"] = {
            "virustotal_per_flag": 10,
            "virustotal_max": 50,
            "gsb_hit": 40,
            "phishtank_hit": 35,
            "visual_clone": 40,
            "domain_age_7days": 30,
            "cert_age_24h": 20,
            "nlp_urgency": 20,
            "url_model_scale": 30,
            "password_field_unknown": 10,
            "form_action_mismatch": 10,
            "iframe_abuse": 15,
        }
        log.warning("⚠ weights_config.json not found — using default weights")

@asynccontextmanager
async def lifespan(app: FastAPI):
    load_models()
    await init_db()
    log.info("🚀 Phishing Shield server ready at 127.0.0.1:8000")
    yield
    log.info("Server shutting down")

# ─────────────────────────────────────────────
# APP
# ─────────────────────────────────────────────
app = FastAPI(title="Phishing Shield API", version="1.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["chrome-extension://*", "http://127.0.0.1", "http://localhost"],
    allow_methods=["POST"],
    allow_headers=["Content-Type"],
)

# ─────────────────────────────────────────────
# SCHEMAS
# ─────────────────────────────────────────────
class URLRequest(BaseModel):
    url: str

class FeedbackRequest(BaseModel):
    url: str
    action: str        # 'proceeded' | 'false_positive'
    score: int = 0

class CacheClearRequest(BaseModel):
    url: str

# ─────────────────────────────────────────────
# MODULE WRAPPERS (with stop_event support)
# ─────────────────────────────────────────────
async def run_url_module(url: str, stop_event: asyncio.Event) -> dict:
    """Run Person B's URL classifier. Returns stub if model not loaded."""
    if stop_event.is_set():
        return {}
    try:
        model = MODELS.get("url_model")
        if model is None:
            return {}  # stub

        # Extract URL features for the model
        from precheck import extract_url_features
        features = extract_url_features(url)

        # Call the model (B's wrapper function expected)
        if hasattr(model, "predict_proba"):
            import numpy as np
            feature_vec = np.array(list(features.values())).reshape(1, -1)
            prob = float(model.predict_proba(feature_vec)[0][1])
        else:
            prob = 0.0

        signals = []
        if features.get("entropy", 0) > 3.8:
            signals.append("High domain entropy (AI-generated pattern)")
        if features.get("has_at_symbol"):
            signals.append("URL contains @ symbol (common phishing trick)")
        if features.get("num_dots", 0) > 4:
            signals.append("Excessive subdomains in URL")

        return {"phishing_probability": prob, "signals": signals}
    except Exception as e:
        log.error(f"URL module error: {e}")
        return {}


async def run_nlp_module(page_text: str, stop_event: asyncio.Event) -> dict:
    """Run Person B's NLP urgency classifier on page text."""
    if stop_event.is_set() or not page_text:
        return {}
    try:
        model = MODELS.get("nlp_model")
        if model is None:
            return {}  # stub

        if hasattr(model, "predict_proba"):
            prob = float(model.predict_proba([page_text])[0][1])
        else:
            prob = 0.0

        patterns = []
        urgency_words = [
            "verify immediately", "account suspended", "click here now",
            "your account will be", "urgent action required", "login immediately",
            "verify your identity", "account locked", "click to verify",
            "aapka account band", "turant karein"  # Hindi patterns
        ]
        text_lower = page_text.lower()
        for word in urgency_words:
            if word in text_lower:
                patterns.append(word)

        return {"urgency_score": prob, "detected_patterns": patterns[:3]}
    except Exception as e:
        log.error(f"NLP module error: {e}")
        return {}


async def run_visual_module(url: str, stop_event: asyncio.Event) -> dict:
    """Run Puppeteer screenshot + pHash brand comparison."""
    if stop_event.is_set():
        return {}
    try:
        page_data = await get_page_data(url, stop_event, MODELS["brand_hashes"])
        return page_data
    except Exception as e:
        log.error(f"Visual module error: {e}")
        return {}


async def run_reputation_module(url: str, stop_event: asyncio.Event) -> dict:
    """VirusTotal + Google Safe Browsing + PhishTank."""
    if stop_event.is_set():
        return {}
    try:
        return await call_reputation_apis(url, stop_event)
    except Exception as e:
        log.error(f"Reputation module error: {e}")
        return {}


async def run_image_module(url: str, stop_event: asyncio.Event) -> dict:
    """Image scan: QR decode + OCR + steganography. Stub until Person B delivers."""
    if stop_event.is_set():
        return {}
    # Person B delivers this module. Stub returns empty.
    return {}

# ─────────────────────────────────────────────
# MAIN ANALYSIS ENDPOINT
# ─────────────────────────────────────────────
@app.post("/analyse")
async def analyse(req: URLRequest):
    url = req.url.strip()
    if not url:
        raise HTTPException(status_code=400, detail="URL is required")

    log.info(f"→ Analysing: {url[:80]}")

    # ── Stage 1: Redis Cache ──
    cached = await check_cache(url)
    if cached:
        log.info(f"  ✓ Cache HIT: {cached['action']} ({cached['score']})")
        return cached

    # ── Stage 2: Pre-check (Alexa + known good) ──
    if is_obviously_safe(url):
        verdict = {"action": "allow", "score": 0, "signals": [], "all_signals": []}
        await write_cache(url, verdict, ttl=3600)
        log.info(f"  ✓ Pre-check ALLOW (trusted domain)")
        return verdict

    # ── Stage 3: Fast Definitive Check (WHOIS + cert age) ──
    fast_result = await fast_definitive_check(url)
    if fast_result.get("early_exit"):
        verdict = fast_result["verdict"]
        await write_cache(url, verdict, ttl=86400)
        await log_verdict(url, verdict)
        log.info(f"  ⚡ Early exit BLOCK (score={verdict['score']})")
        return verdict

    # ── Stage 4: All 5 modules in parallel ──
    stop_event = asyncio.Event()

    results = await asyncio.gather(
        run_url_module(url, stop_event),
        run_reputation_module(url, stop_event),
        run_visual_module(url, stop_event),
        run_image_module(url, stop_event),
        return_exceptions=True
    )

    url_res, api_res, visual_res, img_res = results

    # Get page text for NLP from visual module result (if available)
    page_text = ""
    if isinstance(visual_res, dict):
        page_text = visual_res.get("page_text", "")

    nlp_res = await run_nlp_module(page_text, stop_event)

    # ── Stage 5: Score aggregation ──
    verdict = compute_score(
        module_results=[url_res, api_res, visual_res, nlp_res, img_res],
        weights=MODELS["weights"],
        fast_result=fast_result
    )

    # ── Cache + Log ──
    ttl = 86400 if verdict["action"] == "block" else 3600
    await write_cache(url, verdict, ttl=ttl)
    await log_verdict(url, verdict)

    log.info(f"  → Verdict: {verdict['action'].upper()} (score={verdict['score']})")
    return verdict

# ─────────────────────────────────────────────
# FEEDBACK ENDPOINT
# ─────────────────────────────────────────────
@app.post("/feedback")
async def feedback(req: FeedbackRequest):
    if req.action == "false_positive":
        await log_false_positive(req.url)
    else:
        await log_user_action(req.url, req.action)
    return {"ok": True}

# ─────────────────────────────────────────────
# CACHE CLEAR (called after PIN override)
# ─────────────────────────────────────────────
@app.post("/cache/clear")
async def cache_clear(req: CacheClearRequest):
    await clear_url_cache(req.url)
    return {"ok": True}

# ─────────────────────────────────────────────
# HEALTH CHECK
# ─────────────────────────────────────────────
@app.get("/health")
async def health():
    return {
        "status": "ok",
        "models": {
            "url_model": MODELS.get("url_model") is not None,
            "nlp_model": MODELS.get("nlp_model") is not None,
            "brand_hashes": len(MODELS.get("brand_hashes", {})),
        }
    }

if __name__ == "__main__":
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=False)
