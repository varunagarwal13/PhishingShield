"""
PHISHING SHIELD — puppeteer_bridge.py
Calls the Node.js Puppeteer service (localhost:3001),
gets screenshot + DOM signals, runs pHash brand comparison.
"""

import asyncio
import base64
import io
import logging

import aiohttp

log = logging.getLogger("phishing_shield")

PUPPETEER_URL = "http://localhost:3001/screenshot"
HAMMING_THRESHOLD = 12  # Calibrated by Person B


async def get_page_data(url: str, stop_event: asyncio.Event, brand_hashes: dict) -> dict:
    """
    1. Call Puppeteer service → get screenshot base64 + domSignals + page_text
    2. Compute pHash on screenshot
    3. Compare against brand_hashes library
    4. Return combined result
    """
    if stop_event.is_set():
        return {}

    try:
        timeout = aiohttp.ClientTimeout(total=6)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(PUPPETEER_URL, json={"url": url}) as resp:
                if resp.status == 503:
                    log.warning("Puppeteer pool busy — skipping visual check")
                    return {}
                if resp.status != 200:
                    return {}
                data = await resp.json()
    except asyncio.TimeoutError:
        log.warning(f"Puppeteer timeout for: {url[:60]}")
        return {}
    except Exception as e:
        log.warning(f"Puppeteer call failed: {e}")
        return {}

    result = {
        "dom_signals": data.get("domSignals", {}),
        "page_text": data.get("pageText", ""),
        "visual_clone": False,
        "matched_brand": None,
        "hamming_distance": 999,
    }

    # ── pHash comparison ──
    screenshot_b64 = data.get("screenshot")
    if not screenshot_b64 or not brand_hashes:
        return result

    try:
        import imagehash
        from PIL import Image

        img_bytes = base64.b64decode(screenshot_b64)
        page_hash = imagehash.phash(Image.open(io.BytesIO(img_bytes)))

        best_brand = None
        best_dist = 999

        for brand, brand_hash in brand_hashes.items():
            dist = page_hash - brand_hash
            if dist < best_dist:
                best_dist = dist
                best_brand = brand

        result["hamming_distance"] = best_dist

        if best_dist <= HAMMING_THRESHOLD:
            result["visual_clone"] = True
            result["matched_brand"] = best_brand
            log.info(f"Visual clone detected: matches '{best_brand}' (Hamming={best_dist})")
            stop_event.set()  # Definitive signal — cancel other modules

    except Exception as e:
        log.warning(f"pHash comparison failed: {e}")

    return result
