# INTERFACES.md — Person A ↔ Person B Contract
> Agree on this file BEFORE writing any code. Do not change formats without telling the other person.

---

## Files Person B Delivers → `server/models/`

### 1. `url_model.pkl`
Scikit-learn compatible model (any classifier with `predict_proba` method).

**Input (feature dict → numpy array, same order):**
```python
features = {
    "url_length": int,           # full URL character length
    "domain_length": int,        # domain only
    "num_dots": int,             # dot count in domain
    "num_hyphens": int,
    "num_at_symbols": int,
    "has_at_symbol": int,        # 0 or 1
    "num_digits_in_domain": int,
    "entropy": float,            # Shannon entropy of domain string
    "path_length": int,
    "num_path_slashes": int,
    "has_ip_address": int,       # 0 or 1
    "is_https": int,             # 0 or 1
    "has_suspicious_keywords": int,  # 0 or 1
    "tld_risk_score": float,     # 0.0 = clean TLD, 1.0 = high-risk TLD
    "has_unicode": int,          # 0 or 1
    "min_brand_distance": int,   # Levenshtein distance to closest brand
    "has_double_slash_in_path": int,
    "query_string_length": int,
    "num_subdomains": int,
}
```

**Output (what Person B's wrapper returns):**
```python
{
    "phishing_probability": float,  # 0.0–1.0
    "signals": list[str]            # e.g. ["high entropy", "suspicious TLD"]
}
```

---

### 2. `nlp_model.pkl`
Scikit-learn compatible text classifier with `predict_proba`.

**Input:** raw page text as a single string (max 5000 chars).

**Output:**
```python
{
    "urgency_score": float,          # 0.0–1.0 (>0.7 = trigger NLP penalty)
    "detected_patterns": list[str]   # matched urgency phrases
}
```

---

### 3. `brand_hashes.json`
Dict of brand name → pHash hex string (computed with imagehash.phash).

```json
{
  "sbi": "f8c8e4c0a0a2a4b8",
  "hdfc": "a4b8c0d2e0f0a1b2",
  "icici": "...",
  "paytm": "...",
  "phonepay": "...",
  "google": "...",
  "facebook": "...",
  "amazon": "..."
}
```

Screenshot must be taken at: **1280×600px, top of login page, no animations**.

---

### 4. `weights_config.json`
Scoring weights calibrated by Person B on the training dataset.

```json
{
  "virustotal_per_flag": 10,
  "virustotal_max": 50,
  "gsb_hit": 40,
  "phishtank_hit": 35,
  "visual_clone": 40,
  "domain_age_7days": 30,
  "cert_age_24h": 20,
  "nlp_urgency": 20,
  "url_model_scale": 30,
  "password_field_unknown": 10,
  "form_action_mismatch": 10,
  "iframe_abuse": 15
}
```

---

## Feedback Export (Person A → Person B)
Person A exports weekly from PostgreSQL:

```csv
url, domain, action, score, all_signals, user_action, user_flagged, created_at
```

Rows where: `action IN ('block','warn') AND (user_action='proceeded' OR user_flagged=TRUE)`

Run: `python export_feedback.py` (see README).

---

## Stub Behaviour (before B's files arrive)
| File | Missing behaviour |
|------|-----------------|
| url_model.pkl | returns `{"phishing_probability": 0.0, "signals": []}` |
| nlp_model.pkl | returns `{"urgency_score": 0.0, "detected_patterns": []}` |
| brand_hashes.json | visual clone check disabled (returns no match) |
| weights_config.json | hardcoded defaults in `scoring.py` |
